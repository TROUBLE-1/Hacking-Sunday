.. include:: ../README.rst

Documentation contents
----------------------

.. toctree::
    :maxdepth: 2

    install
    tutorial
    api
    features
    hacking
    changelog

.. include:: ../AUTHORS

.. currentmodule:: weasyprint
.. include:: ../NEWS.rst

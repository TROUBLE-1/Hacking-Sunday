"""
    weasyprint.tests
    ----------------

    The Weasyprint test suite.

    :copyright: Copyright 2011-2019 Simon Sapin and contributors, see AUTHORS.
    :license: BSD, see LICENSE for details.

"""
